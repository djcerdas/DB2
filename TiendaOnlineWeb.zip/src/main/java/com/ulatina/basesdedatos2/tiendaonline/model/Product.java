package com.ulatina.basesdedatos2.tiendaonline.model;

import java.math.BigDecimal;

public class Product {
    private int codigoProducto;
    private String nombre;
    private String talla;
    private String color;
    private String estilo;
    private BigDecimal precioVenta;
    private String imagenUrl;
    private int stockTotal;
    private BigDecimal descuentoPctActivo;
    private BigDecimal precioConDescuento;

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(int codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    public BigDecimal getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(BigDecimal precioVenta) {
        this.precioVenta = precioVenta;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }

    public void setImagenUrl(String imagenUrl) {
        this.imagenUrl = imagenUrl;
    }

    public int getStockTotal() {
        return stockTotal;
    }

    public void setStockTotal(int stockTotal) {
        this.stockTotal = stockTotal;
    }

    public BigDecimal getDescuentoPctActivo() {
        return descuentoPctActivo;
    }

    public void setDescuentoPctActivo(BigDecimal descuentoPctActivo) {
        this.descuentoPctActivo = descuentoPctActivo;
    }

    public BigDecimal getPrecioConDescuento() {
        return precioConDescuento;
    }

    public void setPrecioConDescuento(BigDecimal precioConDescuento) {
        this.precioConDescuento = precioConDescuento;
    }
}
