package com.ulatina.basesdedatos2.tiendaonline.repo;

import com.ulatina.basesdedatos2.tiendaonline.config.Db;
import com.ulatina.basesdedatos2.tiendaonline.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * UserRepository
 *
 * Autenticación muy simple:
 * - Busca por email y password_hash en tabla dbo.users
 * - Junta el primer rol asignado en dbo.user_roles + dbo.roles
 */
public class UserRepository {

    private static final String SQL_LOGIN = """
        SELECT TOP (1)
            u.id,
            u.email,
            r.name AS role_name
        FROM dbo.users u
        JOIN dbo.user_roles ur ON ur.user_id = u.id
        JOIN dbo.roles r       ON r.id = ur.role_id
        WHERE u.email = ? AND u.password_hash = ? AND u.estado = 1
        ORDER BY r.name
        """;

    public User findByEmailAndPassword(String email, String passwordPlain) {
        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_LOGIN)) {

            ps.setString(1, email);
            ps.setString(2, passwordPlain);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int id        = rs.getInt("id");
                    String em     = rs.getString("email");
                    String role   = rs.getString("role_name");
                    return new User(id, em, role);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("Error en login: " + e.getMessage(), e);
        }
        return null;
    }
}
