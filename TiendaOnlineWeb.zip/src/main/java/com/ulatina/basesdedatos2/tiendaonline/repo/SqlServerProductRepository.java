package com.ulatina.basesdedatos2.tiendaonline.repo;

import com.ulatina.basesdedatos2.tiendaonline.config.Db;
import com.ulatina.basesdedatos2.tiendaonline.model.Product;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SqlServerProductRepository {

    private static final String SQL_CATALOG =
        "SELECT codigo_producto, nombre, talla, color, estilo, precio_venta, " +
        "       precio_con_descuento, stock_total, imagen_url " +
        "FROM dbo.v_CatalogoProductos";

    // Simplified for demo. In a real project you may need product variants by size/color.
    public List<Product> findCatalog() {
        List<Product> result = new ArrayList<>();
        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CATALOG);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int codigo = rs.getInt("codigo_producto");
                String nombre = rs.getString("nombre");
                String talla = rs.getString("talla");
                String color = rs.getString("color");
                String estilo = rs.getString("estilo");
                BigDecimal precio = rs.getBigDecimal("precio_venta");
                BigDecimal precioDesc = rs.getBigDecimal("precio_con_descuento");
                int stock = rs.getInt("stock_total");
                String img = rs.getString("imagen_url");

                result.add(new Product(codigo, nombre, talla, color, estilo,
                        precio, precioDesc, stock, img));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error loading catalog", e);
        }
        return result;
    }

    // Example insert method that calls the stored procedure sp_RegistrarProducto.
    public int createProduct(String nombre, String talla, String color, String estilo,
                             BigDecimal precio, String imagenUrl,
                             int cantidadInicial, Date fechaIngreso, String ubicacionBodega) {
        String sql = "{CALL dbo.sp_RegistrarProducto(?, ?, ?, ?, ?, ?, ?, ?, ?)}";
        try (Connection conn = Db.getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setString(1, nombre);
            cs.setString(2, talla);
            cs.setString(3, color);
            cs.setString(4, estilo);
            cs.setBigDecimal(5, precio);
            cs.setString(6, imagenUrl);
            cs.setInt(7, cantidadInicial);
            cs.setDate(8, fechaIngreso);
            cs.setString(9, ubicacionBodega);

            cs.execute();
            // For simplicity, assume SP sets the identity and we don't need the OUT parameter here.
            // In a full implementation, you would register and read the OUT parameter.
            return 1;
        } catch (SQLException e) {
            throw new RuntimeException("Error creating product", e);
        }
    }
}
