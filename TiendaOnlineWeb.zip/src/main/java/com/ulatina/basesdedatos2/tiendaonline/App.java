package com.ulatina.basesdedatos2.tiendaonline;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.ulatina.basesdedatos2.tiendaonline.model.ApiResponse;
import com.ulatina.basesdedatos2.tiendaonline.model.CartItem;
import com.ulatina.basesdedatos2.tiendaonline.model.Product;
import com.ulatina.basesdedatos2.tiendaonline.model.User;
import com.ulatina.basesdedatos2.tiendaonline.repo.CatalogRepository;
import com.ulatina.basesdedatos2.tiendaonline.repo.ReportRepository;
import com.ulatina.basesdedatos2.tiendaonline.repo.StoredProcRepository;
import com.ulatina.basesdedatos2.tiendaonline.repo.UserRepository;

import spark.Filter;

import java.time.LocalDate;
import java.util.List;

import static spark.Spark.*;

public class App {

    public static void main(String[] args) {
        port(8080);
        staticFiles.location("/public");

        ObjectMapper mapper = new ObjectMapper()
                .findAndRegisterModules()
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

        UserRepository userRepo = new UserRepository();
        CatalogRepository catalogRepo = new CatalogRepository();
        StoredProcRepository spRepo = new StoredProcRepository();
        ReportRepository reportRepo = new ReportRepository();

        enableCORS();

        post("/login", (req, res) -> {
            String email    = req.queryParams("email");
            String password = req.queryParams("password");

            if (email == null || password == null) {
                res.status(400);
                return "Missing email or password";
            }

            User user = userRepo.findByEmailAndPassword(email, password);
            if (user == null) {
                res.status(401);
                return "Credenciales inválidas";
            }

            String role = user.getRoleName().toUpperCase();
            String target;
            switch (role) {
                case "OWNER" -> target = "/owner.html";
                case "GESTORINVENTARIO" -> target = "/gestor.html";
                case "VENDEDOR" -> target = "/cliente.html";
                case "CLIENTE" -> target = "/cliente.html";
                case "PROVEEDOR" -> target = "/proveedor.html";
                case "MARKETING" -> target = "/marketing.html";
                default -> target = "/cliente.html";
            }

            res.redirect(target);
            return null;
        });

        get("/api/catalogo", "application/json", (req, res) -> {
            List<Product> catalog = catalogRepo.findCatalog();
            res.type("application/json");
            return mapper.writeValueAsString(catalog);
        });

        post("/api/cart/checkout", "application/json", (req, res) -> {
            try {
                var node = mapper.readTree(req.body());
                String canal       = node.path("canal").asText("web");
                String metodoPago  = node.path("metodoPago").asText("tarjeta");
                Integer idCliente  = node.has("idUsuarioCliente") && !node.get("idUsuarioCliente").isNull()
                        ? node.get("idUsuarioCliente").asInt()
                        : null;

                var itemsNode = node.withArray("items");
                if (itemsNode.isEmpty()) {
                    res.status(400);
                    return mapper.writeValueAsString(new ApiResponse(false, "Carrito vacío"));
                }

                for (var itemNode : itemsNode) {
                    CartItem item = new CartItem();
                    item.setCodigoProducto(itemNode.get("codigoProducto").asInt());
                    item.setCantidad(itemNode.get("cantidad").asInt());

                    spRepo.registrarVentaSimple(idCliente, canal, metodoPago,
                            item.getCodigoProducto(), item.getCantidad());
                }

                res.type("application/json");
                return mapper.writeValueAsString(new ApiResponse(true, "Compra registrada correctamente"));
            } catch (Exception e) {
                res.status(500);
                return mapper.writeValueAsString(new ApiResponse(false, "Error en checkout: " + e.getMessage()));
            }
        });

        post("/api/gestor/producto", "application/json", (req, res) -> {
            try {
                var node = mapper.readTree(req.body());
                String nombre   = node.path("nombre").asText();
                String talla    = node.path("talla").asText();
                String color    = node.path("color").asText();
                String estilo   = node.path("estilo").asText("");
                double precio   = node.path("precioVenta").asDouble();
                String imagen   = node.path("imagenUrl").asText("");
                int cantidadIni = node.path("cantidadInicial").asInt();
                String fechaStr = node.path("fechaIngreso").asText(LocalDate.now().toString());
                String ubic     = node.path("ubicacionBodega").asText("");

                int codigo = spRepo.registrarProducto(
                        nombre,
                        talla,
                        color,
                        estilo,
                        precio,
                        imagen.isBlank() ? null : imagen,
                        cantidadIni,
                        LocalDate.parse(fechaStr),
                        ubic.isBlank() ? null : ubic
                );

                res.type("application/json");
                return mapper.writeValueAsString(
                        new ApiResponse(true, "Producto creado con código " + codigo)
                );
            } catch (Exception e) {
                res.status(500);
                return mapper.writeValueAsString(
                        new ApiResponse(false, "Error creando producto: " + e.getMessage())
                );
            }
        });

        post("/api/gestor/entrada", "application/json", (req, res) -> {
            try {
                var node = mapper.readTree(req.body());
                int codigoProducto = node.path("codigoProducto").asInt();
                int cantidad       = node.path("cantidad").asInt();
                String fechaStr    = node.path("fechaIngreso").asText(LocalDate.now().toString());
                String ubic        = node.path("ubicacionBodega").asText("");

                spRepo.registrarEntradaInventario(
                        codigoProducto,
                        cantidad,
                        LocalDate.parse(fechaStr),
                        ubic.isBlank() ? null : ubic
                );

                res.type("application/json");
                return mapper.writeValueAsString(
                        new ApiResponse(true, "Entrada de inventario registrada")
                );
            } catch (Exception e) {
                res.status(500);
                return mapper.writeValueAsString(
                        new ApiResponse(false, "Error registrando entrada: " + e.getMessage())
                );
            }
        });

        post("/api/gestor/revisar-inventario-envejecido", "application/json", (req, res) -> {
            try {
                var node = mapper.readTree(req.body());
                double descuento = node.path("descuentoPorDefecto").asDouble(20.0);
                int dias         = node.path("diasEnBodega").asInt(60);

                spRepo.revisarInventarioEnvejecido(descuento, dias);

                res.type("application/json");
                return mapper.writeValueAsString(
                        new ApiResponse(true, "Inventario envejecido revisado y ofertas generadas")
                );
            } catch (Exception e) {
                res.status(500);
                return mapper.writeValueAsString(
                        new ApiResponse(false, "Error revisando inventario envejecido: " + e.getMessage())
                );
            }
        });

        get("/api/owner/ventas-diarias", "application/json", (req, res) -> {
            var data = reportRepo.ventasPorDia();
            res.type("application/json");
            return mapper.writeValueAsString(data);
        });

        get("/api/owner/stock-bajo", "application/json", (req, res) -> {
            var data = reportRepo.stockBajo();
            res.type("application/json");
            return mapper.writeValueAsString(data);
        });

        post("/api/proveedor/actualizar-costos", "application/json", (req, res) -> {
            res.type("application/json");
            return mapper.writeValueAsString(
                    new ApiResponse(true,
                            "Endpoint de proveedor listo. Se recomienda implementar un SP específico para costos.")
            );
        });

        get("/api/marketing/ventas-diarias", "application/json", (req, res) -> {
            var data = reportRepo.ventasPorDia();
            res.type("application/json");
            return mapper.writeValueAsString(data);
        });

        get("/api/marketing/stock-bajo", "application/json", (req, res) -> {
            var data = reportRepo.stockBajo();
            res.type("application/json");
            return mapper.writeValueAsString(data);
        });

        get("/health", (req, res) -> "OK TiendaOnlineWeb v2");
    }

    private static void enableCORS() {
        options("/*", (request, response) -> {
            String accessControlRequestHeaders = request.headers("Access-Control-Request-Headers");
            if (accessControlRequestHeaders != null) {
                response.header("Access-Control-Allow-Headers", accessControlRequestHeaders);
            }

            String accessControlRequestMethod = request.headers("Access-Control-Request-Method");
            if (accessControlRequestMethod != null) {
                response.header("Access-Control-Allow-Methods", accessControlRequestMethod);
            }

            return "OK";
        });

        before((Filter) (request, response) -> {
            response.header("Access-Control-Allow-Origin", "*");
            response.header("Access-Control-Request-Method", "*");
            response.header("Access-Control-Allow-Headers", "*");
        });
    }
}
