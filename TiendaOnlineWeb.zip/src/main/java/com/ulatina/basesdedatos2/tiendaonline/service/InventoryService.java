package com.ulatina.basesdedatos2.tiendaonline.service;

import com.ulatina.basesdedatos2.tiendaonline.model.Product;
import com.ulatina.basesdedatos2.tiendaonline.repo.SqlServerProductRepository;

import java.util.List;

public class InventoryService {

    private final SqlServerProductRepository productRepository;

    public InventoryService(SqlServerProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getCatalog() {
        return productRepository.findCatalog();
    }
}
