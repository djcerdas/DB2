package com.ulatina.basesdedatos2.tiendaonline.web;

import com.google.gson.Gson;
import com.ulatina.basesdedatos2.tiendaonline.model.Product;
import com.ulatina.basesdedatos2.tiendaonline.model.User;
import com.ulatina.basesdedatos2.tiendaonline.repo.SqlServerProductRepository;
import com.ulatina.basesdedatos2.tiendaonline.repo.UserRepository;
import com.ulatina.basesdedatos2.tiendaonline.service.AuthService;
import com.ulatina.basesdedatos2.tiendaonline.service.CartService;
import com.ulatina.basesdedatos2.tiendaonline.service.InventoryService;
import spark.Request;
import spark.Response;
import spark.Session;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static spark.Spark.*;

/**
 * Main HTTP entrypoint for TiendaOnlineWeb v2.
 *
 * Endpoints:
 *  - GET  /login.html (static)
 *  - POST /login        (auth)
 *  - GET  /catalog      (JSON catalog)
 *  - POST /cart/add
 *  - POST /cart/remove
 *  - GET  /cart
 *  - GET  /owner/dashboard
 *  - GET  /marketing/dashboard
 */
public class Routes {

    private static final Gson gson = new Gson();

    public static void main(String[] args) {
        port(8080);
        staticFiles.location("/public");

        UserRepository userRepository = new UserRepository();
        AuthService authService = new AuthService(userRepository);
        InventoryService inventoryService = new InventoryService(new SqlServerProductRepository());

        before((req, res) -> {
            String path = req.pathInfo();
            if (path.startsWith("/public") || path.endsWith(".html") || path.startsWith("/css") ||
                path.equals("/login")) {
                return;
            }

            if (path.startsWith("/catalog") || path.startsWith("/cart")) {
                // require login for catalog/cart
                if (getCurrentUser(req) == null) {
                    halt(401, "Unauthorized");
                }
            }
        });

        // --- LOGIN ---
        post("/login", (req, res) -> {
            String email = req.queryParams("email");
            String password = req.queryParams("password");

            User user = authService.login(email, password);
            if (user == null) {
                res.redirect("/login.html?error=1");
                return null;
            }

            Session session = req.session(true);
            session.attribute("user", user);

            switch (user.getAppRole()) {
                case "OWNER":
                    res.redirect("/owner.html");
                    break;
                case "GestorInventario":
                    res.redirect("/gestor.html");
                    break;
                case "Vendedor":
                    res.redirect("/vendedor.html");
                    break;
                case "Cliente":
                    res.redirect("/cliente.html");
                    break;
                case "Proveedor":
                    res.redirect("/proveedor.html");
                    break;
                case "Marketing":
                    res.redirect("/marketing.html");
                    break;
                default:
                    res.redirect("/cliente.html");
            }
            return null;
        });

        // --- API: CURRENT USER ---
        get("/api/me", (req, res) -> {
            User u = getCurrentUser(req);
            res.type("application/json");
            if (u == null) {
                return "{}";
            }
            Map<String, Object> map = new HashMap<>();
            map.put("email", u.getEmail());
            map.put("role", u.getAppRole());
            return gson.toJson(map);
        });

        // --- API: CATALOG ---
        get("/api/catalog", (req, res) -> {
            User u = getCurrentUser(req);
            if (u == null) {
                res.status(401);
                return "Unauthorized";
            }

            List<Product> catalog = inventoryService.getCatalog();
            res.type("application/json");
            return gson.toJson(catalog);
        });

        // --- API: CART MANAGEMENT ---
        post("/api/cart/add", (req, res) -> {
            User u = getCurrentUser(req);
            if (u == null) {
                res.status(401);
                return "Unauthorized";
            }

            CartService cart = getOrCreateCart(req);
            int codigo = Integer.parseInt(req.queryParams("codigoProducto"));
            String nombre = req.queryParams("nombre");
            String talla = req.queryParams("talla");
            String color = req.queryParams("color");
            int cantidad = Integer.parseInt(req.queryParams("cantidad"));
            BigDecimal precio = new BigDecimal(req.queryParams("precioUnitario"));

            cart.addItem(codigo, nombre, talla, color, cantidad, precio);

            Map<String, Object> resp = new HashMap<>();
            resp.put("ok", true);
            resp.put("total", cart.getTotal().toPlainString());
            res.type("application/json");
            return gson.toJson(resp);
        });

        post("/api/cart/remove", (req, res) -> {
            User u = getCurrentUser(req);
            if (u == null) {
                res.status(401);
                return "Unauthorized";
            }
            CartService cart = getOrCreateCart(req);
            int codigo = Integer.parseInt(req.queryParams("codigoProducto"));
            String talla = req.queryParams("talla");
            String color = req.queryParams("color");
            cart.removeItem(codigo, talla, color);

            Map<String, Object> resp = new HashMap<>();
            resp.put("ok", true);
            resp.put("total", cart.getTotal().toPlainString());
            res.type("application/json");
            return gson.toJson(resp);
        });

        get("/api/cart", (req, res) -> {
            User u = getCurrentUser(req);
            if (u == null) {
                res.status(401);
                return "Unauthorized";
            }
            CartService cart = getOrCreateCart(req);
            res.type("application/json");
            return gson.toJson(cart.getItems());
        });

        // --- OWNER DASHBOARD (JSON stub) ---
        get("/api/owner/dashboard", (req, res) -> {
            User u = getCurrentUser(req);
            if (u == null || !"OWNER".equals(u.getAppRole())) {
                res.status(403);
                return "Forbidden";
            }
            Map<String, Object> data = new HashMap<>();
            data.put("mensaje", "Owner dashboard metrics will be implemented here (ventas, top productos, etc.)");
            res.type("application/json");
            return gson.toJson(data);
        });

        // --- MARKETING DASHBOARD (JSON stub) ---
        get("/api/marketing/dashboard", (req, res) -> {
            User u = getCurrentUser(req);
            if (u == null || !"Marketing".equals(u.getAppRole())) {
                res.status(403);
                return "Forbidden";
            }
            Map<String, Object> data = new HashMap<>();
            data.put("mensaje", "Marketing dashboard: métricas, segmentación, campañas y ofertas sugeridas.");
            res.type("application/json");
            return gson.toJson(data);
        });
    }

    private static User getCurrentUser(Request req) {
        Session session = req.session(false);
        return session == null ? null : session.attribute("user");
    }

    private static CartService getOrCreateCart(Request req) {
        Session session = req.session(true);
        CartService cart = session.attribute("cart");
        if (cart == null) {
            cart = new CartService();
            session.attribute("cart", cart);
        }
        return cart;
    }
}
